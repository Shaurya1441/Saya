import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name:'filter'
})
export class MyPipe implements PipeTransform{
    transform(details: any[], doamin:string):any[] {
        if(!details){
            return [];
        }
        if(!doamin){
            return details;
        }
        return details.filter(dt=>{ return dt.Domain==doamin;})
    }
    
}