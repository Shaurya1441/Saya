import {Injectable,OnInit} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {IProject} from '../Models/MyProjectModel';

@Injectable()
export class ProjectService implements OnInit{

    url:string="/assets/data.json";
    ngOnInit(): void{
        this.getDetails();
    }
    constructor(private _http:HttpClient){

    }

    getDetails(){return this._http.get<IProject[]>(this.url);}
}