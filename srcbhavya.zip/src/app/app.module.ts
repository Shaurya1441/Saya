import {HttpClientModule} from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {ProjectService} from './Services/ProjectService';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import {ProjectDisplayComponent} from './DisplayComponent/app-project-display.component';
import {MyPipe} from './Pipe/MyPipe';

import { AppComponent } from './app.component';

@NgModule({
  declarations: [
    AppComponent,
    ProjectDisplayComponent,
    MyPipe
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [ProjectService],
  bootstrap: [AppComponent]
})
export class AppModule { }
