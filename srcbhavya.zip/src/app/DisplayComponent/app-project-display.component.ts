import { Component, OnInit } from '@angular/core';
import { ProjectService } from '../Services/ProjectService';
import { IProject } from '../Models/MyProjectModel';
import {FormBuilder,FormGroup} from '@angular/forms';

@Component({
  selector: 'app-project-display',
  templateUrl: './app-project-display.component.html',
  styleUrls: ['./app-project-display.component.css']
})
export class ProjectDisplayComponent implements OnInit {
  details:IProject[];
  submitted:Boolean=false;
  
  constructor(private recservice:ProjectService,private formBuilder:FormBuilder) { }

  ngOnInit() {
    this.getAll();
  }
  getAll(){
    this.recservice.getDetails().subscribe(data=>{
        this.details=data;});

}

onSubmit(){
  this.submitted=true;
  this.recservice.getDetails().subscribe(data=>{
      this.details=data;
  
  }) 
 
}
txtchanged(){
  this.submitted=false;
}
}
